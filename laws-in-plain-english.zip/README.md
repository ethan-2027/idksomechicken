# Laws in Plain English

A small Vite + React + Tailwind website that explains common legal topics in short, plain-language summaries. Designed for high schoolers and civic-minded creators.

## Features
- Browse topics (voting, police stops, tenant rights, etc.)
- Short plain-English summaries with "Read more"
- Search and filter
- Easily extensible JSON content

## Quick start (local)

1. Install dependencies:

```bash
npm install
```

2. Run dev server:

```bash
npm run dev
```

3. Build for production:

```bash
npm run build
```

## Push to GitHub (example)

```bash
git init
git add .
git commit -m "Initial commit — Laws in Plain English"
git remote add origin git@github.com:YOUR_USERNAME/laws-in-plain-english.git
git branch -M main
git push -u origin main
```

## License
MIT
