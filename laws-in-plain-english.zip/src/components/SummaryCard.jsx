import React from 'react'

export default function SummaryCard({ topic, onExpand }){
  return (
    <article className="p-4 bg-white rounded shadow flex justify-between items-start">
      <div>
        <h3 className="text-lg font-semibold">{topic.title}</h3>
        <p className="text-slate-600 mt-1">{topic.summary}</p>
        <div className="mt-2 text-xs text-slate-500">Tags: {topic.tags.join(', ')}</div>
      </div>

      <div className="ml-4 flex-shrink-0">
        <button onClick={onExpand} className="px-3 py-1 border rounded">Read more</button>
      </div>
    </article>
  )
}
