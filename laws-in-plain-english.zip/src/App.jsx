import React, { useState } from 'react'
import topics from './data/topics.json'
import SummaryCard from './components/SummaryCard'

export default function App(){
  const [q, setQ] = useState('')
  const [selected, setSelected] = useState(null)

  const filtered = topics.filter(t => (
    t.title.toLowerCase().includes(q.toLowerCase()) ||
    t.tags.join(' ').toLowerCase().includes(q.toLowerCase()) ||
    t.summary.toLowerCase().includes(q.toLowerCase())
  ))

  return (
    <div className="min-h-screen bg-slate-50 p-6">
      <header className="max-w-4xl mx-auto">
        <h1 className="text-3xl font-extrabold mb-2">Laws in Plain English</h1>
        <p className="text-slate-600 mb-4">Short, clear explanations of legal topics for students and citizens.</p>

        <div className="flex gap-2">
          <input
            aria-label="Search topics"
            value={q}
            onChange={e => setQ(e.target.value)}
            placeholder="Search voting, police, tenant..."
            className="flex-1 p-2 border rounded"
          />
          <button className="p-2 border rounded" onClick={() => setQ('')}>Clear</button>
        </div>
      </header>

      <main className="max-w-4xl mx-auto mt-6 grid grid-cols-1 gap-4">
        {filtered.map(topic => (
          <SummaryCard key={topic.id} topic={topic} onExpand={() => setSelected(topic)} />
        ))}

        {filtered.length === 0 && (
          <div className="p-6 bg-white rounded shadow">No results — try a different search.</div>
        )}

        {selected && (
          <section className="p-6 bg-white rounded shadow">
            <h2 className="text-2xl font-semibold">{selected.title}</h2>
            <p className="mt-3 text-slate-700">{selected.long}</p>
            <div className="mt-4">
              <button className="px-3 py-1 border rounded" onClick={() => setSelected(null)}>Close</button>
            </div>
          </section>
        )}
      </main>

      <footer className="max-w-4xl mx-auto mt-8 text-sm text-slate-500">
        <p>Made for students. Not legal advice.</p>
      </footer>
    </div>
  )
}
